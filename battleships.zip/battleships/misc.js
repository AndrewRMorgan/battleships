<table>
  <tr>
    <td id='square00'></td><td id='square01'></td><td id='square02'></td><td id='square03'></td><td id='square04'></td><td id='square05'></td><td id='square06'></td><td id='square07'></td><td id='square08'></td><td id='square09'></td>
  </tr>
  <tr>
    <td id='square10'></td><td id='square11'></td><td id='square12'></td><td id='square13'></td><td id='square14'></td><td id='square15'></td><td id='square16'></td><td id='square17'></td><td id='square18'></td><td id='square19'></td>
  </tr>
  <tr>
    <td id='square20'></td><td id='square21'></td><td id='square22'></td><td id='square23'></td><td id='square24'></td><td id='square25'></td><td id='square26'></td><td id='square27'></td><td id='square28'></td><td id='square29'></td>
  </tr>
  <tr>
    <td id='square30'></td><td id='square31'></td><td id='square32'></td><td id='square33'></td><td id='square34'></td><td id='square35'></td><td id='square36'></td><td id='square37'></td><td id='square38'></td><td id='square39'></td>
  </tr>
  <tr>
    <td id='square40'></td><td id='square41'></td><td id='square42'></td><td id='square43'></td><td id='square44'></td><td id='square45'></td><td id='square46'></td><td id='square47'></td><td id='square48'></td><td id='square49'></td>
  </tr>
  <tr>
    <td id='square50'></td><td id='square51'></td><td id='square52'></td><td id='square53'></td><td id='square54'></td><td id='square55'></td><td id='square56'></td><td id='square57'></td><td id='square58'></td><td id='square59'></td>
  </tr>
  <tr>
    <td id='square60'></td><td id='square61'></td><td id='square62'></td><td id='square63'></td><td id='square64'></td><td id='square65'></td><td id='square66'></td><td id='square67'></td><td id='square68'></td><td id='square69'></td>
  </tr>
  <tr>
    <td id='square70'></td><td id='square71'></td><td id='square72'></td><td id='square73'></td><td id='square74'></td><td id='square75'></td><td id='square76'></td><td id='square77'></td><td id='square78'></td><td id='square79'></td>
  </tr>
  <tr>
    <td id='square80'></td><td id='square81'></td><td id='square82'></td><td id='square83'></td><td id='square84'></td><td id='square85'></td><td id='square86'></td><td id='square87'></td><td id='square88'></td><td id='square89'></td>
  </tr>
  <tr>
    <td id='square00'></td><td id='square01'></td><td id='square02'></td><td id='square03'></td><td id='square04'></td><td id='square05'></td><td id='square06'></td><td id='square07'></td><td id='square08'></td><td id='square09'></td>
  </tr>
  <tr>
    <td id='square00'></td><td id='square01'></td><td id='square02'></td><td id='square03'></td><td id='square04'></td><td id='square05'></td><td id='square06'></td><td id='square07'></td><td id='square08'></td><td id='square09'></td>
  </tr>
</table>
